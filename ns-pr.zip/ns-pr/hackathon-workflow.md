# Hackathon Workflow Reference

**Purpose:** End-to-end process reference for press, Devpost, demo, and system diagrams.  
**Not intended as finished press copy.**  
**Reference date:** 2026-08-29

## End-to-End Workflow

### 1. Source Administration

An administrator configures and approves a news Source and its endpoint.

Configuration may include:

- source identity;
- approved domain rules;
- endpoint URL;
- endpoint type;
- source/endpoint lifecycle state;
- optional RSS/Atom item filter;
- relevance/category configuration;
- Distribution Profile membership.

Only approved, active, enabled sources/endpoints are eligible for collection while publication collection is active.

### 2. Scheduled Collection

The Worker executes scheduled or manually requested endpoint collection.

Collection occurs outside the ordinary visitor/request path.

A failing source does not stop other sources from collecting.

### 3. Network Safety

Before the collector contacts an endpoint, the system applies the configured trust and network-safety rules.

Redirects are also validated before contact.

### 4. Source Parsing

The configured endpoint adapter parses the source.

Primary adapter paths:

- RSS/Atom;
- bounded static HTML.

Both produce a common raw-item representation for downstream processing.

### 5. Normalization

Source-specific fields are converted to the shared normalized article-candidate model.

Normalization happens before outward use and before AI grounding.

Normalized fields may include:

- headline;
- source;
- publication/effective feed date;
- author;
- bounded summary;
- original URL;
- categories.

### 6. Article Policy, Relevance, Identity, and Persistence

The normalized candidate passes through shared application rules.

These include:

- article-link/source policy validation;
- relevance/category rules;
- source-scoped article identity;
- idempotent persistence;
- provenance/observation recording.

Repeated collection of the same unchanged source item does not create additional logical article records.

### 7. Duplicate Handling

The system can group true duplicates across retained source article records.

Ordinary outward output uses one Primary article for a true-duplicate group.

Underlying source article instances and provenance remain stored.

### 8. Canonical Outward Eligibility

The application determines which normalized articles are currently eligible for outward distribution.

This authority is reused by downstream consumers.

Gemini does not replace this step.

### 9. Distribution Profile Selection

A Distribution Profile narrows the already-eligible canonical article set for a particular feed/section.

The Profile cannot restore an article that canonical rules excluded.

### 10. Digest Evaluation

For each enabled Profile digest, the server evaluates the digest on a schedule.

Current default behavior:

- two evaluations per day;
- 7-day rolling lookback;
- maximum 20 input articles;
- canonical Profile order preserved.

The system derives the exact bounded input and compares it with the previous successful digest input.

If the governed input and relevant digest configuration are unchanged, a scheduled evaluation can skip the Gemini call.

### 11. Gemini Request Construction

When generation is required, the application constructs a bounded Gemini request.

Per-article context is limited to approved normalized outward data such as:

- article ID;
- headline;
- source display name;
- effective feed date;
- publication date when available;
- author when available;
- bounded persisted summary;
- effective categories;
- exact stored original URL.

The application may provide the exact stored original URLs to Gemini URL Context.

The model cannot expand the URL set.

### 12. Gemini Digest Generation

Current provider path:

- Gemini 3.6 Flash;
- Gemini Developer API;
- Interactions API;
- Google GenAI SDK;
- URL Context;
- structured JSON output;
- Google Search grounding disabled.

Gemini produces:

- overview;
- up to 3 highlights;
- supporting article IDs.

### 13. Application Validation

News Scraper validates the Gemini output before persistence or distribution.

Validation includes:

- structured response shape;
- text bounds;
- supporting article IDs;
- support references restricted to the exact generation input;
- duplicate support IDs within a highlight.

The application resolves final supporting article metadata and original URLs from its governed data.

Model-provided replacement URLs are not trusted.

### 14. Durable Digest Activation

A valid digest is persisted as an immutable successful generation.

The Profile owns a separate active-digest reference.

Activation occurs only after the complete digest has been generated, validated, and persisted.

The active pointer is changed atomically.

### 15. Distribution API

The active digest becomes part of the same complete outward Profile snapshot as the articles.

The authenticated v1 distribution API exposes:

- Profile data;
- publication data;
- normalized articles;
- nullable active digest.

There is no separate customer digest endpoint required for the current implementation.

### 16. Scheduled PHP Synchronization

A customer-side scheduled PHP process retrieves the complete Profile snapshot through the authenticated API.

This is separate from ordinary visitor traffic.

### 17. Local Validation and Last-Known-Good State

The PHP integration validates the candidate snapshot before activation.

It stores validated state locally.

If optional digest data is malformed but the article snapshot is valid:

- the valid article snapshot can still activate;
- the local digest becomes `null`.

AI failure does not make the ordinary customer feed unavailable.

### 18. Customer Website Rendering

The existing customer website reads normalized local state.

Ordinary visitor rendering:

- does not call Gemini;
- does not call the News Scraper API;
- does not require the Gemini key;
- uses server-side PHP rendering;
- keeps headline/supporting links pointed at original publisher URLs.

The customer controls the final presentation.

## Workflow Summary for a Diagram

Use this shortened sequence for the high-level workflow graphic:

```text
Approved Sources
    ↓
Scheduled Collection
    ↓
Parse + Normalize
    ↓
Govern + Persist + Deduplicate
    ↓
Distribution Profile
    ↓
Bounded Digest Input
    ↓
Gemini 3.6 Flash
    ↓
Validate + Persist + Activate
    ↓
Authenticated Profile API
    ↓
Scheduled PHP Sync
    ↓
Local Last-Known-Good State
    ↓
Customer Website
```

## Recommended Architecture-Diagram Boundaries

The technical architecture diagram should visibly distinguish:

### Source Layer

- approved RSS/Atom sources;
- approved bounded static-HTML sources.

### News Scraper Backend

- Worker / collection;
- canonical processing;
- PostgreSQL;
- Distribution Profile/read model;
- digest orchestration;
- Web/API.

### Google AI

- Google GenAI SDK;
- Gemini 3.6 Flash;
- URL Context.

### Google Cloud

- **Pending final infrastructure service selection and deployment.**
- Add the real service only after implementation.

### Customer Integration

- authenticated v1 API consumer;
- scheduled PHP synchronization;
- local LKG state;
- customer server-rendered website.

## Important Diagram Rule

Do not draw Gemini ahead of the governed Distribution Profile.

Correct:

```text
Canonical eligible articles
→ Distribution Profile
→ bounded digest input
→ Gemini
```

Incorrect:

```text
raw internet/news
→ Gemini chooses the feed
```
