# Hackathon Project Reference

**Purpose:** Factual reference for writing press, Devpost, demo, and social material.  
**Not intended as finished press copy.**  
**Project:** News Scraper  
**Repository:** `jfin602/news-scraper`  
**Reference date:** 2026-08-29

## Product

News Scraper is a reusable, topic-independent news aggregation and distribution platform.

The platform:

- collects article metadata from administrator-approved sources;
- prefers RSS/Atom or other structured feeds where available;
- supports bounded static-HTML source adapters when needed;
- normalizes source-specific input before outward use;
- persists article records idempotently;
- preserves source and collection provenance;
- groups true duplicates while retaining the underlying source article records;
- applies governed relevance, category, moderation, duplicate, and distribution rules;
- exposes normalized article output through Distribution Profiles;
- preserves the original publisher URL as the reader destination.

The first customer configuration focuses on publishing-industry news relevant to indie authors. That subject is configuration, not shared aggregation-engine behavior.

## Customer Use

The customer uses News Scraper as a backend news aggregation and distribution system for an existing PHP website.

The current customer-facing path is:

1. News Scraper collects and processes source articles.
2. A Distribution Profile selects the governed outward feed.
3. The authenticated News Scraper v1 API exposes the complete Profile snapshot.
4. A scheduled PHP integration synchronizes that snapshot.
5. The PHP integration validates and stores a local last-known-good snapshot.
6. The customer website renders from the local normalized data.
7. Headline links continue to point to the original publishers.

The customer owns the final HTML, CSS, layout, placement, and presentation.

## Gemini Digest Capability

The current implemented Gemini capability is a scheduled Profile digest.

Key facts:

- Provider: Google Gemini.
- Current configured model: `gemini-3.6-flash`.
- API path: Gemini Developer API using the Interactions API.
- SDK: official Google `@google/genai` SDK.
- Gemini is downstream of the governed Distribution Profile.
- Gemini does not approve sources.
- Gemini does not decide canonical article eligibility.
- Gemini does not replace relevance, category, moderation, duplicate, or ordering rules.
- Gemini does not create reader destination URLs.
- The application controls the exact article URLs supplied for Gemini URL Context.
- Persisted normalized article summaries remain available as fallback context.
- Source/article text and provider-retrieved publisher content are treated as untrusted input.

## Digest Input

Default digest evaluation behavior:

- two scheduled evaluations per day for each enabled Profile digest;
- default rolling lookback: 7 days;
- default maximum input: 20 articles;
- hard Phase 1 article-count ceiling: 20;
- canonical Profile order is preserved;
- zero qualifying articles means no new digest;
- one qualifying article is sufficient;
- scheduled evaluation may skip the Gemini call when the governed input and relevant AI configuration are unchanged.

Manual generation uses the same governed input, provider, validation, persistence, and activation path.

## Digest Output

The application requests structured output and validates it before use.

The visible digest contains:

- an overview;
- up to 3 highlights/key developments;
- up to 3 supporting article references per highlight.

Supporting references are returned by Gemini as article IDs from the exact bounded input.

News Scraper then:

- validates each supporting article ID;
- rejects references outside the generation input;
- resolves the real headline, source, date, and original URL from governed application data;
- does not trust model-generated URLs or replacement article metadata.

## Persistence and Failure Handling

Successful digest generations are durable records.

The Profile has a separate active-digest reference.

Replacement follows this sequence:

1. generate;
2. validate;
3. persist the complete digest;
4. atomically switch the active digest reference.

A failed Gemini request does not make the ordinary article feed unavailable.

Possible outward digest states are:

- `current`;
- `older`;
- no active digest (`null`).

The customer website does not call Gemini during an ordinary visitor page request.

## Useful Architecture Facts

- Web/API and Worker responsibilities are separated.
- Source collection does not run inline on public/customer requests.
- PostgreSQL stores durable application state.
- Source failures are isolated.
- Network safety checks occur before outbound collection requests and redirects.
- Article identity is source-scoped and idempotent.
- True-duplicate suppression does not delete source provenance.
- Distribution Profiles narrow already-governed eligible articles.
- AI is optional and downstream of the canonical distribution boundary.
- Gemini credentials remain server-side.
- PHP synchronization maintains local last-known-good state.
- Visitor rendering is local-only after synchronization.

## Current Project Status

As of 2026-08-29:

- package baseline: `2.2.0`;
- Gemini Profile digest foundation: implemented and owner-accepted;
- current work immediately following Phase 1: bounded Profile digest writing-style configuration and PHP integration/package hardening;
- later planned work includes Profile-grounded interactive Gemini chat.

Do not describe planned chat as currently implemented.

## Claims to Avoid

Do not state that:

- Gemini searches the unrestricted web;
- Gemini decides which sources are trustworthy;
- Gemini verifies that news reports are true;
- Gemini controls publication eligibility;
- Gemini chooses the final reader URLs;
- the website calls Gemini for every visitor;
- the system republishes full publisher articles;
- collection is literally real-time;
- the current system is a multi-tenant SaaS;
- planned interactive chat is already live;
- Google Cloud infrastructure is already part of the deployed architecture unless that deployment has been completed and verified.

## Information the Customer Should Supply

Before final press or submission copy is written, record:

- customer/publication name;
- customer role/title;
- customer website URL;
- name, if any, for the AI digest feature;
- intended reader/audience;
- previous manual workflow;
- main problem the customer wanted solved;
- customer quote;
- preferred developer/project credit;
- call to action;
- confirmed metrics that can be published;
- whether submission is individual/team or on behalf of an incorporated organization.
