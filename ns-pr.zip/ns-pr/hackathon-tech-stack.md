# Hackathon Tech Stack Reference

**Purpose:** Technology inventory and component responsibilities.  
**Not intended as finished press copy.**  
**Reference date:** 2026-08-29

## Core Application

| Technology | Current Use |
| --- | --- |
| Node.js 24 | Application runtime |
| TypeScript 6 | Primary application language |
| Express 5 | Web/API HTTP layer |
| PostgreSQL | Durable application, article, distribution, job, and digest state |
| `pg` | PostgreSQL client |
| RSS / Atom | Preferred structured source input |
| `fast-xml-parser` | XML/RSS/Atom parsing |
| Static HTML adapter | Bounded source collection for configured HTML listings |
| Cheerio | HTML parsing/selection |
| Cron / scheduled jobs | Collection, digest evaluation, and customer synchronization scheduling |
| REST/JSON API | Machine distribution interface |
| PHP | Customer integration and server-rendered website consumption |

## Google / Gemini Stack

| Technology | Current Use |
| --- | --- |
| Gemini 3.6 Flash | Scheduled Profile digest generation |
| Gemini Developer API | Gemini provider access |
| Interactions API | Gemini request interface used by the provider integration |
| Google GenAI SDK (`@google/genai`) | Official Google SDK used by the Node.js backend |
| Gemini URL Context | Allows Gemini to retrieve the exact governed article URLs supplied by the application |
| Structured JSON output | Application-validated digest response format |
| `store=false` | Provider request configuration for digest generation |
| Low thinking | Current digest-generation reasoning setting |
| Google Search grounding | Disabled for the digest path |

## Google Agent Framework Requirement

The hackathon accepts the Google GenAI SDK as a qualifying Google Agent Framework.

Current status:

- `@google/genai` is already used by News Scraper.
- This satisfies the framework portion of the hackathon technical requirement, subject to final submission review.

## Google Cloud Infrastructure Requirement

The hackathon separately requires at least one Google Cloud infrastructure service.

Examples listed by the rules include:

- Cloud Run;
- Cloud SQL;
- Firestore;
- Google Kubernetes Engine (GKE);
- Pub/Sub.

**Current project status:** repository review on 2026-08-29 did not identify a Google Cloud infrastructure deployment.

**Submission status:** unresolved requirement.

Do not list Cloud Run, Cloud SQL, Firestore, GKE, Pub/Sub, Vertex AI, or another Google Cloud infrastructure service as part of the implemented stack until it has actually been integrated and verified.

The final architecture diagram and demo must be updated after the selected Google Cloud component is implemented.

## Distribution and Customer Integration

| Component | Responsibility |
| --- | --- |
| Distribution Profile | Selects a configured subset of already-governed eligible articles |
| Authenticated v1 API | Exposes complete Profile snapshots to machine consumers |
| PHP synchronization package | Periodically downloads and validates the complete Profile snapshot |
| Local last-known-good state | Keeps a validated local snapshot available to the customer site |
| `LocalProfileReader` / normalized local read | Supported customer-facing data boundary |
| Customer PHP/HTML/CSS | Final presentation and server-side rendering |
| Original publisher URLs | Reader destination for article headlines/support references |

## AI Safety and Data Boundaries

| Boundary | Implementation |
| --- | --- |
| Source trust | Administrator-approved sources only |
| AI article selection | Derived from canonical Distribution Profile output |
| Digest input size | Bounded; default 7 days and up to 20 articles |
| URL Context scope | Exact stored original URLs from the bounded governed input |
| Prompt-injection handling | Source/retrieved text treated as untrusted data |
| Output validation | Application-owned structured schema |
| Supporting references | Gemini returns allowed article IDs; application resolves real metadata/URLs |
| Gemini credentials | Server-side only |
| AI failure behavior | Ordinary collection/distribution/rendering remains available |
| Visitor AI dependency | None for ordinary digest display |

## Testing / Quality Tooling

| Technology / Check | Current Use |
| --- | --- |
| Node test runner | Unit/integration/collection/security/database tests |
| Playwright | Browser validation |
| ESLint | Static linting |
| TypeScript compiler | Type checking |
| Prettier | Formatting validation |
| Live Gemini test path | Explicit live-provider qualification |
| Database-focused tests | Persistence/migration behavior |
| PHP test path | PHP integration validation |

## Optional Technologies That Should Not Be Claimed Without Verification

Do not add these to a public stack list solely because they are common or planned:

- Docker / Docker Compose;
- Kubernetes;
- WordPress;
- Redis;
- vector database / embeddings;
- Pub/Sub;
- Vertex AI;
- Cloud Run;
- Cloud SQL;
- Firestore;
- Google ADK;
- Genkit;
- multi-agent framework.

Only list them if they are actually added to the submission build.
