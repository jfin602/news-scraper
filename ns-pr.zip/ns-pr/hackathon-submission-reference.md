# Hackathon Submission Reference

**Hackathon:** All Things Agentic Hackathon  
**Organizer/Sponsor:** Google / Devpost  
**Reference date:** 2026-08-29  
**Rules source:** https://allthingsagentichackathon.devpost.com/rules  
**FAQ source:** https://allthingsagentichackathon.devpost.com/details/faqs

**Purpose:** Factual submission checklist and writing reference.  
**Not intended as finished press or Devpost copy.**

## Contest Dates

Current published rules:

- Contest/submission period begins: August 3, 2026 at 9:00 AM Pacific Time.
- Submission deadline: August 31, 2026 at 5:00 PM Pacific Time.
- Judging period: September 1 through October 1, 2026.
- Winners currently listed as announced on or around October 8, 2026.

Re-check the Devpost rules immediately before submission.

## Mandatory Technology Requirements

Every project must use all three:

1. Gemini 3.5 or newer through Gemini API or Vertex AI.
2. At least one qualifying Google Agent Framework:
   - Google ADK;
   - GenAI SDK;
   - Antigravity SDK;
   - Genkit.
3. At least one Google Cloud infrastructure service, with examples including:
   - Cloud Run;
   - Cloud SQL;
   - Firestore;
   - GKE;
   - Pub/Sub.

## Current News Scraper Requirement Status

| Requirement | Status | Evidence / Note |
| --- | --- | --- |
| Gemini 3.5+ | Met in current implementation | `gemini-3.6-flash` |
| Gemini API or Vertex AI | Met in current implementation | Gemini Developer API |
| Google Agent Framework | Met in current implementation | Google GenAI SDK (`@google/genai`) |
| Google Cloud infrastructure service | **Not yet evidenced** | Must be implemented and verified before submission |

### Required Action

Select and implement an appropriate Google Cloud infrastructure service before submission.

The project should not be described as hackathon-compliant until this requirement is met.

The implementation should preserve News Scraper's existing architecture requirement that ordinary operation not become permanently dependent on a mandatory central service solely because of the hackathon deployment.

## Category Reference

The rules currently list three categories:

1. Taskmaster
2. Collaborative Partner
3. Fortified Enterprise Fleet

### Likely Fit: Taskmaster

Taskmaster asks for a complete workflow rather than a chatbot and emphasizes autonomous completion of multi-step background work.

News Scraper's current workflow characteristics relevant to that category include:

- scheduled/background collection;
- automatic normalization and persistence;
- canonical filtering and duplicate handling;
- scheduled change-aware Gemini digest evaluation;
- structured Gemini generation;
- output validation;
- durable activation;
- automatic API distribution;
- scheduled customer synchronization;
- local customer rendering without a visitor-triggered AI call.

**Final category selection belongs to the entrant.**

## Submission Materials Required by the Rules

Current rules require or call for:

- one selected category;
- hosted Project URL if available; hosted access is strongly encouraged;
- text description covering:
  - features/functionality;
  - technologies used;
  - other data sources;
  - findings/learnings;
- code repository URL;
- repository access for judges if private;
- README spin-up instructions;
- architecture diagram;
- demonstration video;
- English materials or English translation/subtitles.

### Private Repository Access

If the submitted repository is private, the current rules state access must be provided to:

- `testing@devpost.com`
- `cloudhackathons@google.com`

Verify this again immediately before submission.

## Demo Video Requirements

Current rules state:

- demo should cover the problem;
- demo should cover the value proposition;
- demo should show the application in action;
- demo must show proof that the backend is running on Google Cloud;
- acceptable proof examples include Google Cloud Console, Cloud Run dashboard, Vertex AI logs, or a `.run` URL;
- video should be no longer than 4 minutes;
- only the first 4 minutes may be evaluated if longer;
- video must be publicly visible on YouTube or Vimeo;
- video must be in English or include English subtitles.

## Proof of Action

The judging section specifically asks for visible live execution.

Useful News Scraper evidence could include:

- a live scheduled/manual digest evaluation;
- Worker/application log showing the digest evaluation;
- database state change for a successful generation;
- admin state showing generation result;
- customer site changing after synchronized digest state;
- Cloud infrastructure execution/log proof.

Do not simulate or describe evidence as live if it was not actually observed.

## Architecture Diagram Requirement

The diagram should clearly show:

- source inputs;
- collection Worker;
- backend/API;
- PostgreSQL;
- Distribution Profile;
- Gemini connection;
- selected Google Cloud infrastructure service;
- PHP synchronization;
- customer website.

The diagram should make the AI authority boundary clear:

```text
governed Profile articles
→ bounded digest input
→ Gemini
→ validation
→ durable active digest
```

It should not imply that Gemini controls source approval, canonical eligibility, or final publisher URLs.

## Judging Criteria

Current published weights:

### Innovation & Operational Utility — 40%

Relevant questions from the rules:

- Does the system eliminate real-world friction?
- Does it perform high-value autonomous execution rather than simple chat?
- For Taskmaster, does it complete a multi-step background workflow without human intervention?

Useful factual evidence to collect:

- number of sources monitored;
- number of articles collected;
- number of scheduled workflow steps removed from manual work;
- number of digests produced;
- amount of customer/manual effort replaced;
- frequency of automatic updates.

Only use measured/verified numbers.

### Architectural Discipline & Tech Stack — 30%

Relevant News Scraper facts:

- separate Worker and Web/API responsibilities;
- durable PostgreSQL state;
- administrator-approved source trust;
- network safety boundary;
- source-scoped idempotent article identity;
- provenance retention;
- duplicate grouping without source-record deletion;
- canonical outward read authority;
- bounded Gemini input;
- structured-output validation;
- atomic digest activation;
- failure isolation;
- server-side credentials;
- local last-known-good customer state;
- visitor rendering independent of Gemini availability.

### Demo & Production Readiness — 30%

Relevant requirements/evidence:

- clear problem statement;
- live application execution;
- architecture diagram;
- reproducible setup;
- working hosted path where appropriate;
- visible Google Cloud deployment proof.

## New-Project / Pre-Existing Work Rule

The current rules state that projects must be newly created during the submission period.

They allow standard development tools, frameworks, libraries, starter templates, and AI coding assistants.

They also state that other pre-existing code or work incorporated into the Project must be disclosed.

News Scraper repository documentation dates the project establishment to August 6, 2026, which falls within the published August 3–31 submission period.

However:

- the customer's existing frontend website may contain older/pre-existing work;
- any other pre-existing components incorporated into the submission should be identified accurately.

Do not make a blanket statement that every part of the customer website was created during the hackathon unless that is true.

## Data Sources to Describe

The submission description should identify the general source types used.

News Scraper currently supports:

- administrator-approved RSS/Atom sources;
- administrator-approved bounded static-HTML listing sources.

The system is not an unrestricted web crawler.

The application may also provide governed original article URLs to Gemini URL Context during digest generation.

## Findings / Learnings Worth Recording

The Devpost text description asks for findings and learnings.

Possible factual areas to document after confirming with the developer/customer:

- why AI was placed downstream of canonical article governance;
- why Gemini output is schema-validated before activation;
- why article IDs are used for support references instead of trusting model-generated URLs;
- why visitor rendering is decoupled from Gemini;
- why local last-known-good state is used for customer integration;
- how paywalled/inaccessible publisher pages are handled with normalized summary fallback;
- how change-aware evaluation avoids unnecessary Gemini calls;
- how source failures and AI failures are isolated.

These are prompts for the entrant to write about, not finished statements for a press release.

## Optional Bonus Contributions

Current rules list bonus contributions.

### Public Build Content

A public blog, podcast, or video about how the project was built may earn bonus credit.

Current rule requirement:

- it must be public;
- it must state that the content was created for the purpose of entering the hackathon.

The planned press/build article may be usable for this if it satisfies the final rules.

### Social Media

A public project post on X, LinkedIn, Instagram, or Facebook may earn bonus credit.

Current rules specify the hashtag:

`#AllThingsAgenticHackathon`

### Additional Google AI Models

The rules also provide bonus points for qualifying additional Google AI model integrations.

Do not add another model only for a marketing claim; only list an integration that is actually implemented and relevant.

## Customer Information Needed Before Final PR / Submission Writing

Collect the following:

- legal/display name of entrant;
- individual, team, or incorporated-organization submission;
- customer/publication name;
- customer website URL;
- customer role/title;
- developer/team credits;
- project start date;
- what work was completed during the submission period;
- any pre-existing frontend/site code that should be disclosed;
- selected hackathon category;
- selected Google Cloud infrastructure service;
- Google Cloud deployment proof;
- hosted project/testing URL;
- repository visibility/access plan;
- confirmed source/article/digest metrics;
- customer quote;
- problem description in the customer's own words;
- findings/learnings in the entrant's own words.

## Claims / Submission Checks

Before publishing or submitting, verify that copy does not claim:

- unrestricted Gemini web search;
- AI-controlled source approval;
- AI-controlled canonical feed selection;
- AI fact verification;
- AI-generated reader URLs;
- visitor-time Gemini generation;
- full-article republishing;
- literal real-time delivery;
- Google Cloud deployment before it exists;
- planned chat functionality as implemented;
- unsupported metrics;
- unobserved test/runtime behavior.

## Final Pre-Submission Checklist

- [ ] Gemini 3.5+ requirement satisfied.
- [ ] Google GenAI SDK/framework requirement satisfied.
- [ ] Google Cloud infrastructure service implemented.
- [ ] Google Cloud deployment verified.
- [ ] Architecture diagram updated with actual cloud service.
- [ ] Demo contains visible Google Cloud proof.
- [ ] Demo contains live proof of action.
- [ ] Demo is 4 minutes or less.
- [ ] Video is public on YouTube or Vimeo.
- [ ] Repository access is configured for judges.
- [ ] README contains spin-up/deploy instructions.
- [ ] Hosted/test access is available where applicable.
- [ ] Category selected.
- [ ] Text description includes features, technologies, data sources, findings, and learnings.
- [ ] Pre-existing work is disclosed where required.
- [ ] Metrics are verified.
- [ ] Press/build content uses only verified claims.
- [ ] Optional bonus-content rules re-checked before publication.
- [ ] Devpost rules re-checked immediately before final submission.
